# beetroot > 2024-12-16 11:47am
https://universe.roboflow.com/dd-0zn1r/beetroot-2ohux

Provided by a Roboflow user
License: CC BY 4.0

