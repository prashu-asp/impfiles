# green > 2023-06-30 5:13pm
https://universe.roboflow.com/curry/green-zecem

Provided by a Roboflow user
License: CC BY 4.0

