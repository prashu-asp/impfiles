# celery > 2023-07-28 11:25am
https://universe.roboflow.com/project-tdi8l/celery-is683

Provided by a Roboflow user
License: CC BY 4.0

